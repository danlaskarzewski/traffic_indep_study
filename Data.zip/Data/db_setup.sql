/* ENDPTS
RED- Alewife: 70061, Braintree: 70105, Ashmont: 70093, 70094
	LIMITED- Savin Hill: (70087, 70088), Davis: (70063, 70064)
BLUE- Wonderland: (70059, 70060), Bowdoin: (70038, 70838)
ORANGE- Forest Hills: 70001, Oak Grove: 70036
	LIMITED-  Malden Center: (70034, 70035), Green St: (70002, 70003)
GREEN- Medford/Tufts: (?), Union Square: (), Boston College: (), Riverside: (), Heath Street: (), Cleveland Circle: ()
	LIMITED- Lechmere: (70209, 70210), Copley: (70154, 70155)
*/


-- DROP TABLE IF EXISTS MBTA_endpoints;

-- CREATE TABLE MBTA_endpoints (
-- 	row_num INTEGER,
-- 	service_date DATE,
-- 	route_id VARCHAR(255),
-- 	trip_id VARCHAR(255),
-- 	direction_id INTEGER,
-- 	stop_id INTEGER,
-- 	stop_sequence INTEGER,
-- 	vehicle_id VARCHAR(255),
-- 	vehicle_label VARCHAR(255),
-- 	event_type VARCHAR(255),
-- 	event_time INTEGER,
-- 	event_time_sec INTEGER,
-- 	train_type VARCHAR(2)
-- );

-- DROP TABLE IF EXISTS temp_full_endpts;
-- CREATE TABLE temp_full_endpts (
-- 	b INTEGER,
-- 	service_date DATE,
-- 	route_id VARCHAR(255),
-- 	trip_id VARCHAR(255),
-- 	direction_id INTEGER,
-- 	dep_stop_id INTEGER,
--  	arr_stop_id INTEGER,
-- 	vehicle_id VARCHAR(255),
-- 	vehicle_label VARCHAR(255),
-- 	train_type VARCHAR(2),
-- 	dep_time INTEGER,
-- 	next_arr_time INTEGER,
-- 	travel_time_sec INTEGER,
-- 	dep_datetime DATETIME,
-- 	dep_year INTEGER,
-- 	dep_month INTEGER,
-- 	dep_day INTEGER,
-- 	dep_hour INTEGER
-- );

-- LOAD DATA LOCAL INFILE '/Users/danlaskarzewski/Documents/DU/Y4Q2/traffic_indep_study/Data/full_endpts.csv'
-- INTO TABLE temp_full_endpts
-- FIELDS TERMINATED BY ','
-- IGNORE 1 ROWS;

-- SELECT *
-- FROM MBTA_endpoints
-- LIMIT 10;

-- SELECT COUNT(row_num)
-- FROM MBTA_endpoints;

-- DELETE FROM MBTA_endpoints WHERE NOT (event_type = "ARR" OR event_type = "DEP");


-- DROP TABLE IF EXISTS blue_ends;
-- CREATE TABLE blue_ends (
-- 	row_num INTEGER,
-- 	service_date DATE,
-- 	route_id VARCHAR(255),
-- 	trip_id VARCHAR(255),
-- 	direction_id INTEGER,
-- 	stop_id INTEGER,
-- 	stop_sequence INTEGER,
-- 	vehicle_id VARCHAR(255),
-- 	vehicle_label VARCHAR(255),
-- 	event_type VARCHAR(255),
-- 	event_time INTEGER,
-- 	event_time_sec INTEGER,
-- 	train_type VARCHAR(2)
-- );
	-- ORANGE LIMITED-  Malden Center: (70034, 70035), Green St: (70002, 70003)
	-- RED LIMITED- Savin Hill: (70087, 70088), Davis: (70063, 70064)
	-- GREEN LIMITED- Lechmere: (70209, 70210), Copley: (70154, 70155)


-- INSERT INTO blue_ends
-- SELECT * FROM MBTA_endpoints
-- WHERE (stop_id = 70209 OR stop_id = 70210 OR stop_id = 70154 OR stop_id = 70155) AND route_id LIKE "Green%";



-- INSERT INTO endpt_travel_times
-- SELECT *,
--     event_time AS dep_time,
--     (SELECT event_time AS next_arr_time
--      FROM blue_ends t1
--      	WHERE vehicle_id=blue_ends.vehicle_id 
-- 		AND event_type='ARR' 
-- 		AND event_time>blue_ends.event_time 
-- 		AND stop_id != blue_ends.stop_id 
-- 		AND service_date = blue_ends.service_date
-- 		AND direction_id = blue_ends.direction_id
--      ORDER BY event_time ASC LIMIT 1) AS next_arr_time
-- FROM blue_ends
-- LIMIT 100;

-- FROM blue_ends
-- WHERE event_type='DEP'
-- LIMIT 50;
-- select * from blue_ends;

-- DELETE FROM blue_ends
-- WHERE LENGTH(trip_id) < 2;
-- AND service_date NOT LIKE "%2020-03-%" ; 
-- delete 11379 rows from 2020-01-01 to 2020-03-31 with only 2192 occuring outside of March

-- DROP TABLE IF EXISTS b_endpt_travel_times;
-- CREATE TABLE b_endpt_travel_times (
-- 	service_date DATE,
-- 	route_id VARCHAR(255),
-- 	trip_id VARCHAR(255),
-- 	direction_id INTEGER,
-- 	dep_stop_id INTEGER,
--  	arr_stop_id INTEGER,
-- 	vehicle_id VARCHAR(255),
-- 	vehicle_label VARCHAR(255),
-- 	train_type VARCHAR(2),
-- 	dep_time INTEGER,
-- 	next_arr_time INTEGER,
-- 	travel_time_sec INTEGER
-- );

-- -- INSERT INTO b_endpt_travel_times
-- CREATE OR REPLACE VIEW b_endpts AS
-- SELECT 
-- 	depBlue.service_date AS service_date,
-- 	depBlue.route_id AS route_id,
-- 	depBlue.trip_id AS trip_id,
-- 	depBlue.direction_id AS direction_id,
-- 	depBlue.stop_id AS dep_stop_id,
--  	arrBlue.stop_id AS arr_stop_id,
-- 	depBlue.vehicle_id AS vehicle_id,
-- 	depBlue.vehicle_label AS vehicle_label,
-- 	depBlue.train_type AS train_type,
-- 	depBlue.event_time AS dep_time,
-- 	arrBlue.event_time AS next_arr_time,
-- 	MIN(arrBlue.event_time - depBlue.event_time) AS travel_time_sec
-- FROM (SELECT * FROM blue_ends WHERE event_type = "ARR") AS arrBlue, 
-- 	(SELECT * FROM blue_ends WHERE event_type = "DEP") AS depBlue
-- WHERE arrBlue.vehicle_id = depBlue.vehicle_id 
-- 	AND arrBlue.vehicle_label = depBlue.vehicle_label
-- 	AND arrBlue.stop_id != depBlue.stop_id
-- 	AND arrBlue.service_date = depBlue.service_date
-- 	AND arrBlue.direction_id = depBlue.direction_id
-- 	AND arrBlue.event_time > depBlue.event_time
-- 	AND arrBlue.trip_id = depBlue.trip_id
-- 	AND LENGTH(depBlue.trip_id) > 1
-- GROUP BY depBlue.route_id, depBlue.vehicle_id, depBlue.event_time, arrBlue.event_time,
-- 	depBlue.service_date,depBlue.trip_id,depBlue.direction_id,depBlue.stop_id, 
-- 	arrBlue.stop_id,	depBlue.vehicle_label, depBlue.train_type
-- ORDER BY arrBlue.event_time;


-- SELECT * FROM blue_ends
-- WHERE stop_id = '70036' AND event_type = 'ARR';

-- INSERT INTO b_endpt_travel_times
-- SELECT * FROM b_endpts 
-- WHERE (next_arr_time,travel_time_sec) IN 
-- 	(SELECT next_arr_time, MIN(travel_time_sec) FROM b_endpts GROUP BY next_arr_time);

	-- SELECT * FROM b_endpt_travel_times WHERE next_arr_time IN
	-- (SELECT next_arr_time FROM b_endpt_travel_times GROUP BY next_arr_time HAVING COUNT(*) > 1 ORDER BY next_arr_time);

-- SELECT dep_stop_id, arr_stop_id, 
-- AVG(ABS(travel_time_sec)) as avg_time, 
-- ROUND(STDDEV(ABS(travel_time_sec)),1) as std_time,
-- MIN(ABS(travel_time_sec)) as min_time,
-- MAX(ABS(travel_time_sec)) as max_time,
-- COUNT(travel_time_sec) as num_deps
-- FROM g_endpt_travel_times
-- GROUP BY dep_stop_id, arr_stop_id;

-- SELECT route_id, dep_stop_id, arr_stop_id, 
-- AVG(ABS(travel_time_sec)) as avg_time, 
-- ROUND(STDDEV(ABS(travel_time_sec)),1) as std_time,
-- MIN(ABS(travel_time_sec)) as min_time,
-- MAX(ABS(travel_time_sec)) as max_time,
-- COUNT(travel_time_sec) as num_deps
-- FROM r_endpt_travel_times
-- GROUP BY dep_stop_id, arr_stop_id, route_id;

-- SELECT route_id, dep_stop_id, arr_stop_id, 
-- AVG(ABS(travel_time_sec)) as avg_time, 
-- ROUND(STDDEV(ABS(travel_time_sec)),1) as std_time,
-- MIN(ABS(travel_time_sec)) as min_time,
-- MAX(ABS(travel_time_sec)) as max_time,
-- COUNT(travel_time_sec) as num_deps
-- FROM o_endpt_travel_times
-- GROUP BY dep_stop_id, arr_stop_id, route_id;

-- SELECT route_id, dep_stop_id, arr_stop_id, 
-- AVG(ABS(travel_time_sec)) as avg_time, 
-- ROUND(STDDEV(ABS(travel_time_sec)),1) as std_time,
-- MIN(ABS(travel_time_sec)) as min_time,
-- MAX(ABS(travel_time_sec)) as max_time,
-- COUNT(travel_time_sec) as num_deps
-- FROM b_endpt_travel_times
-- GROUP BY dep_stop_id, arr_stop_id, route_id;

-- CREATE OR REPLACE VIEW temp_endpts AS 
-- SELECT * FROM b_endpt_travel_times UNION
-- SELECT * FROM g_endpt_travel_times UNION
-- SELECT * FROM r_endpt_travel_times UNION
-- SELECT * FROM o_endpt_travel_times;

-- DROP TABLE IF EXISTS full_endpts;
-- CREATE TABLE full_endpts AS
-- SELECT * FROM temp_endpts
-- WHERE NOT (dep_stop_id = 70064 OR dep_stop_id = 70209 OR dep_stop_id = 70064 OR dep_stop_id = 70087 OR dep_stop_id = 70035 OR dep_stop_id = 70002 OR dep_stop_id = 70060 OR dep_stop_id = 70838);

-- SELECT route_id, dep_stop_id, arr_stop_id, 
-- AVG(ABS(travel_time_sec)) as avg_time, 
-- ROUND(STDDEV(ABS(travel_time_sec)),1) as std_time,
-- MIN(ABS(travel_time_sec)) as min_time,
-- MAX(ABS(travel_time_sec)) as max_time,
-- COUNT(travel_time_sec) as num_deps
-- FROM full_endpts
-- GROUP BY dep_stop_id, arr_stop_id, route_id;


-- CREATE TABLE hr_avgs AS
-- SELECT 
-- 	route_id,
-- 	dep_stop_id, 
-- 	dep_year, 
-- 	dep_month, 
-- 	dep_day, 
-- 	dep_hour, 
-- 	AVG(travel_time_sec) AS avg_travel_time,
-- 	COUNT(travel_time_sec) AS num_trips 
-- FROM temp_full_endpts 
-- GROUP BY dep_year, dep_month, dep_day, dep_hour, dep_stop_id, route_id;

SELECT route_id, dep_stop_id, AVG(travel_time_sec) FROM full_endpts 
GROUP BY route_id, dep_stop_id;
-- SELECT route_id, dep_stop_id
-- FROM hr_avgs
-- GROUP BY dep_stop_id, route_id;

-- COMBO STOP IDS
-- ["Blue_70038", "Blue_70059", "Red_70063", "Red_70088", "Orange_70003", "Orange_70034", "Green-E_70154", "Green-E_70210", "Green-B_70154", "Green-B_70210", "Green-C_70154", "Green-C_70210", "Green-D_70154", "Green-D_70210"]

-- SELECT * FROM temp_full_endpts WHERE dep_day = 1 AND dep_hour = 7 LIMIT 50;